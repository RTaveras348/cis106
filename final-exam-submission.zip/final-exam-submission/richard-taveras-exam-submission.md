# Final Submission

## Question 1
![q1](q1.png)

## Question 2
![q2]()

## Question 3
1[q3]()